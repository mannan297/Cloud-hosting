MANNAN CLOUD - Premium Dashboard (frontend only)

1. Upload ALL files in this folder to the same directory on your server or hosting.
2. Open index.html  -> User Dashboard
   Open admin.html  -> Super Admin Dashboard

Files:
  index.html, style.css, app.js     User dashboard
  admin.html, admin.css, admin.js   Admin dashboard
  premium.css, premium.js           Premium styling and animations
  icons.js                          SVG icons
  files.js                          File Manager + Help page

Note: this is a frontend prototype. Projects, charts, users and activity are demo data.
The File Manager edits sample files in the browser only (nothing is saved to a server).
There is no login page in this version. Do not expose admin.html publicly without server-side protection.
