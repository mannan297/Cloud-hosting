const pages=["overview","users","projects","runtimes","docker","limits","server","security","activity"];
const names={overview:"Overview",users:"User Management",projects:"All Projects",runtimes:"Runtime Versions",docker:"Docker Images",limits:"Resource Limits",server:"Server Settings",security:"Security & Access",activity:"Activity Logs"};
const nav=document.querySelectorAll("[data-page]"),sections=document.querySelectorAll(".page"),crumb=document.getElementById("crumb"),sidebar=document.getElementById("sidebar");
function showPage(key){if(!pages.includes(key))key="overview";sections.forEach(s=>s.classList.toggle("active",s.id==="page-"+key));nav.forEach(n=>n.classList.toggle("active",n.dataset.page===key));crumb.textContent=names[key];sidebar.classList.remove("open");window.scrollTo({top:0,behavior:"smooth"});}
nav.forEach(n=>n.addEventListener("click",()=>showPage(n.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.go)));
document.getElementById("menu").addEventListener("click",()=>sidebar.classList.toggle("open"));
const toast=document.getElementById("toast");let timer;
function notify(msg){toast.textContent=msg;toast.classList.add("show");clearTimeout(timer);timer=setTimeout(()=>toast.classList.remove("show"),2800);}
["addUser","addRuntime","pullImage","saveLimits","exportLogs"].forEach(id=>{const el=document.getElementById(id);if(el)el.addEventListener("click",()=>notify("Preview interface only — this action will be connected to the secure backend later."));});
document.querySelectorAll(".row-action").forEach(b=>b.addEventListener("click",()=>notify("Management action will be available after backend integration.")));
document.querySelectorAll(".toolbar input").forEach(input=>input.addEventListener("input",()=>{const q=input.value.toLowerCase();const table=input.closest(".page")?.querySelector("tbody");if(table)table.querySelectorAll("tr").forEach(row=>row.style.display=row.innerText.toLowerCase().includes(q)?"":"none");}));
