const pages = ["overview","projects","create","resources","files","runtime","console","settings","support"];
const labels = {overview:"Overview",projects:"My Projects",create:"Create Project",resources:"Resource Usage",files:"File Manager",runtime:"Runtime Manager",console:"Console & Logs",settings:"Settings",support:"Help & Support"};
const navButtons = document.querySelectorAll("[data-page]");
const pageEls = document.querySelectorAll(".page");
const crumb = document.getElementById("crumb");
const sidebar = document.getElementById("sidebar");
function showPage(name){
  if(!pages.includes(name)) name="overview";
  pageEls.forEach(p=>p.classList.toggle("active",p.id===`page-${name}`));
  navButtons.forEach(b=>b.classList.toggle("active",b.dataset.page===name));
  crumb.textContent=labels[name];
  sidebar.classList.remove("open");
  window.scrollTo({top:0,behavior:"smooth"});
}
navButtons.forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.go)));
document.getElementById("menuBtn").addEventListener("click",()=>sidebar.classList.toggle("open"));

const versions = {
  "Python":["3.15","3.14","3.13","3.12"],
  "Node.js":["26","24","22","20"],
  "PHP":["8.4","8.3","8.2"],
  "Java":["25","21","17"],
  "Custom Docker":["Custom image"]
};
let selectedRuntime="Python";
const versionSelect=document.getElementById("runtimeVersion");
const nameInput=document.getElementById("projectName");
function updateSummary(){
  const name=nameInput.value.trim()||"Your project";
  document.getElementById("summaryName").textContent=name;
  document.getElementById("summaryRuntime").textContent=`${selectedRuntime} · ${versionSelect.value}`;
}
function setRuntime(runtime){
  selectedRuntime=runtime;
  document.querySelectorAll(".runtime-option").forEach(b=>b.classList.toggle("selected",b.dataset.runtime===runtime));
  versionSelect.innerHTML="";
  versions[runtime].forEach(v=>{const opt=document.createElement("option");opt.value=v;opt.textContent=v;versionSelect.appendChild(opt)});
  updateSummary();
}
document.querySelectorAll(".runtime-option").forEach(b=>b.addEventListener("click",()=>setRuntime(b.dataset.runtime)));
nameInput.addEventListener("input",updateSummary);
versionSelect.addEventListener("change",updateSummary);
setRuntime("Python");

const toast=document.getElementById("toast");
let toastTimer;
function notify(message){
  toast.textContent=message;toast.classList.add("show");
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),3000);
}
document.getElementById("createBtn").addEventListener("click",()=>{
  const name=nameInput.value.trim();
  if(!name){notify("Please enter a project name first.");nameInput.focus();return;}
  notify(`Preview only: ${name} (${selectedRuntime} ${versionSelect.value}) is ready for backend integration.`);
});
document.querySelectorAll(".outline-btn").forEach(b=>b.addEventListener("click",()=>notify("Project controls will be connected after backend integration.")));
document.querySelectorAll(".dots").forEach(b=>b.addEventListener("click",()=>notify("More project actions will be available here.")));
