/* MANNAN CLOUD — SVG icon set (replaces text glyphs) */
(()=>{
const P={
grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
box:'<path d="M21 8 12 3 3 8v8l9 5 9-5V8Z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
gauge:'<path d="M3 13a9 9 0 1 1 18 0"/><path d="m12 13 4-4"/><circle cx="12" cy="13" r="1.2"/>',
folder:'<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
chip:'<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
term:'<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="m7 10 3 2.5L7 15M13 15h4"/>',
gear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
help:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="m5.6 5.6 3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9"/>',
users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>',
db:'<ellipse cx="12" cy="5.5" rx="8" ry="3"/><path d="M4 5.5v13c0 1.7 3.6 3 8 3s8-1.3 8-3v-13M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
server:'<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/>',
shield:'<path d="M12 3 4 6v6c0 5 3.4 8 8 9 4.6-1 8-4 8-9V6l-8-3Z"/><path d="m9 12 2 2 4-4"/>',
clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
bell:'<path d="M6 9a6 6 0 1 1 12 0c0 6 2 7.5 2 7.5H4S6 15 6 9Z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
file:'<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/>',
upload:'<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
down:'<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
save:'<path d="M5 3h11l4 4v14H5z"/><path d="M8 3v5h7M8 21v-7h8v7"/>',
chev:'<path d="m9 6 6 6-6 6"/>',
mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
book:'<path d="M4 4h6a3 3 0 0 1 3 3v14a2 2 0 0 0-2-2H4zM20 4h-6a3 3 0 0 0-3 3v14a2 2 0 0 1 2-2h7z"/>',
out:'<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',
chat:'<path d="M4 5h16v11H9l-5 4z"/>'};
const svg=(n,s=18)=>`<svg class="ic" viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n]||P.grid}</svg>`;
window.icon=svg;
const NAV={overview:'grid',projects:'box',create:'plus',resources:'gauge',files:'folder',runtime:'chip',console:'term',settings:'gear',support:'help',
users:'users',runtimes:'chip',docker:'db',limits:'gauge',server:'server',security:'shield',activity:'clock'};
document.querySelectorAll('[data-page]').forEach(b=>{const t=b.querySelector('.nav-icon')||b.querySelector(':scope > i');if(t)t.innerHTML=svg(NAV[b.dataset.page]||'grid')});
const COL={cyan:'box',purple:'chip',blue:'server',orange:'db'};
document.querySelectorAll('.metric-icon,.quick-icon').forEach(e=>{const c=Object.keys(COL).find(k=>e.classList.contains(k));if(c)e.innerHTML=svg(e.classList.contains('quick-icon')?({cyan:'plus',purple:'folder',blue:'term',orange:'chip'})[c]:COL[c],16)});
document.querySelectorAll('.icon-btn').forEach(b=>{const em=b.querySelector('em');b.innerHTML=svg('bell',19);if(em)b.appendChild(em)});
document.querySelectorAll('.runtime-badge.docker,.placeholder-icon').forEach(e=>{if(e.classList.contains('docker'))e.innerHTML=svg('box',18)});
})();
