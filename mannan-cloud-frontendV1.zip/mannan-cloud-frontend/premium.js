/* MANNAN CLOUD — Premium behaviour layer */
(()=>{
  const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
  const bar=document.createElement('div');bar.id='pbar';document.body.appendChild(bar);
  const progress=()=>{bar.style.opacity=1;bar.style.width='70%';setTimeout(()=>{bar.style.width='100%';setTimeout(()=>{bar.style.opacity=0;bar.style.width='0'},250)},220)};

  // real date + time-aware greeting (replaces the hard-coded text)
  const now=new Date(),h=now.getHours();
  const eyebrow=$('#page-overview .eyebrow'),h1=$('#page-overview h1');
  if(eyebrow)eyebrow.textContent=now.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'}).toUpperCase();
  if(h1&&h1.firstChild)h1.firstChild.textContent=h<12?'Good morning':h<17?'Good afternoon':h<21?'Good evening':'Good night';

  // staggered reveal for cards when a page opens
  const reveal=page=>{if(!page)return;$$('.metric-card,.panel,.project-card,.runtime-card,.security-card,.stat,.welcome-row,.page-title-row',page).forEach((el,i)=>{el.classList.remove('reveal');void el.offsetWidth;el.style.animationDelay=(i*55)+'ms';el.classList.add('reveal')})};
  const watchPages=()=>$$('.page').forEach(p=>new MutationObserver(()=>{if(p.classList.contains('active')){progress();reveal(p)}}).observe(p,{attributes:true,attributeFilter:['class']}));
  watchPages();reveal($('.page.active'));

  // count-up for big metric numbers (keeps the <small> unit untouched)
  $$('.metric-value').forEach(v=>{const t=v.firstChild;if(!t||t.nodeType!==3)return;const m=t.textContent.trim().match(/^(\d+(?:\.\d+)?)$/);if(!m)return;
    const end=parseFloat(m[1]),dec=(m[1].split('.')[1]||'').length,pad=m[1].length>1&&m[1][0]==='0'&&!dec,t0=performance.now();
    const tick=n=>{const k=Math.min(1,(n-t0)/900),e=1-Math.pow(1-k,3),val=end*e;t.textContent=(pad?String(Math.round(val)).padStart(m[1].length,'0'):val.toFixed(dec))+(k<1?'':' ');if(k<1)requestAnimationFrame(tick)};requestAnimationFrame(tick)});

  // button ripple
  document.addEventListener('click',e=>{const b=e.target.closest('.primary-btn,.primary,.outline-btn,.upgrade-btn');if(!b)return;
    const r=b.getBoundingClientRect(),s=Math.max(r.width,r.height),d=document.createElement('span');d.className='ripple';
    d.style.cssText=`width:${s}px;height:${s}px;left:${e.clientX-r.left-s/2}px;top:${e.clientY-r.top-s/2}px`;
    if(getComputedStyle(b).position==='static')b.style.position='relative';b.style.overflow='hidden';b.appendChild(d);setTimeout(()=>d.remove(),600)});

  // "/" focuses search, Esc closes mobile menu
  document.addEventListener('keydown',e=>{const t=e.target.tagName;if(e.key==='/'&&!/INPUT|SELECT|TEXTAREA/.test(t)){const s=$('.search-input');if(s){e.preventDefault();$$('[data-page="projects"]')[0]?.click();setTimeout(()=>s.focus(),50)}}
    if(e.key==='Escape')$('#sidebar')?.classList.remove('open')});
})();
