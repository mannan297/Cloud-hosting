/* MANNAN CLOUD — File Manager + Help centre (user dashboard). Demo data lives in browser memory only. */
(()=>{
const I=window.icon,say=m=>window.notify&&notify(m),esc=s=>s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const fs={
'main.py':'import logging\nfrom config.settings import BOT_TOKEN\nfrom utils.helpers import greet\n\nlogging.basicConfig(level=logging.INFO)\n\ndef main():\n    logging.info("Starting telegram-assistant")\n    print(greet("MANNAN"))\n\nif __name__ == "__main__":\n    main()\n',
'requirements.txt':'python-telegram-bot==21.6\nrequests==2.32.3\npython-dotenv==1.0.1\n',
'.env.example':'BOT_TOKEN=your-token-here\nADMIN_ID=123456789\n',
'config/settings.py':'import os\nfrom dotenv import load_dotenv\n\nload_dotenv()\nBOT_TOKEN = os.getenv("BOT_TOKEN", "")\nADMIN_ID = int(os.getenv("ADMIN_ID", "0"))\n',
'utils/helpers.py':'def greet(name: str) -> str:\n    return f"Hello, {name}!"\n',
'logs/app.log':'[INFO] Sample log file (demo)\n'};
const enc=encodeURIComponent;let live=false,proj='';
const call=async(m,u,b)=>{const r=await fetch(u,{method:m,credentials:'same-origin',headers:{'X-Requested-With':'mannan',...(b?{'Content-Type':'application/json'}:{})},body:b?JSON.stringify(b):undefined});let d={};try{d=await r.json()}catch(e){}if(r.status===401){location.replace('login.html');throw new Error('Session expired')}if(!r.ok)throw new Error(d.error||'Request failed');return d};
let cur='main.py',dirty=false,open={config:1,utils:1,logs:0};
const fp=document.getElementById('page-files');if(fp){
fp.innerHTML=`<div class="page-title-row"><div><div class="eyebrow">PROJECT TOOLS</div><h1>File Manager<span class="accent">.</span></h1><p class="muted">Browse, edit and download your project files.</p></div><div class="fm-actions"><button class="outline-btn" id="fmNew">${I('plus',15)} New file</button><label class="outline-btn fm-up">${I('upload',15)} Upload<input type="file" id="fmUp" hidden multiple></label></div></div>
<div class="panel fm"><aside class="fm-tree"><div class="fm-proj"><span class="project-logo python">Py</span><div><strong>telegram-assistant</strong><small>/home/app</small></div></div><div id="fmTree"></div></aside>
<section class="fm-edit"><div class="fm-bar"><span id="fmPath" class="fm-path"></span><span id="fmDirty" class="fm-dirty">● unsaved</span><span class="fm-sp"></span><button class="icon-sm" id="fmSave" title="Save (Ctrl+S)">${I('save',16)}</button><button class="icon-sm" id="fmDl" title="Download">${I('down',16)}</button><button class="icon-sm danger" id="fmDel" title="Delete">${I('trash',16)}</button></div>
<div class="fm-code"><pre id="fmNums" aria-hidden="true"></pre><textarea id="fmText" spellcheck="false" wrap="off"></textarea></div><div class="fm-foot"><span id="fmInfo"></span><span>UTF-8 · Preview mode: changes stay in this browser until the backend is connected</span></div></section></div>`;
const T=document.getElementById('fmText'),N=document.getElementById('fmNums');
const nums=()=>{N.textContent=T.value.split('\n').map((_,i)=>i+1).join('\n');N.scrollTop=T.scrollTop;document.getElementById('fmInfo').textContent=`${T.value.split('\n').length} lines · ${new Blob([T.value]).size} B`};
const tree=()=>{const dirs={},root=[];Object.keys(fs).sort().forEach(p=>{const s=p.split('/');if(s.length>1)(dirs[s[0]]=dirs[s[0]]||[]).push(p);else root.push(p)});
const row=(p,d)=>`<button class="fm-file${p===cur?' on':''}" style="padding-left:${12+d*16}px" data-f="${p}">${I('file',15)}<span>${esc(p.split('/').pop())}</span></button>`;
document.getElementById('fmTree').innerHTML=Object.keys(dirs).sort().map(d=>`<button class="fm-dir${open[d]?' open':''}" data-d="${d}">${I('chev',14)}${I('folder',15)}<span>${d}</span></button>`+(open[d]?dirs[d].map(p=>row(p,1)).join(''):'')).join('')+root.map(p=>row(p,0)).join('')};
const load=async p=>{if(dirty&&!confirm('Discard unsaved changes?'))return;cur=p;dirty=false;if(live&&fs[p]===null){try{fs[p]=(await call('GET','/api/file?project='+enc(proj)+'&path='+enc(p))).content}catch(e){return say(e.message)}}T.value=fs[p]??'';document.getElementById('fmPath').textContent='/home/app/'+p;document.getElementById('fmDirty').style.display='none';tree();nums()};
const save=async()=>{if(!(cur in fs))return;if(live){try{await call('PUT','/api/file',{project:proj,path:cur,content:T.value})}catch(e){return say(e.message)}}fs[cur]=T.value;dirty=false;document.getElementById('fmDirty').style.display='none';say(live?`Saved ${cur}`:`Saved ${cur} (preview, in browser only)`)};
document.getElementById('fmTree').onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.d){open[b.dataset.d]=!open[b.dataset.d];tree()}else if(b.dataset.f)load(b.dataset.f)};
T.oninput=()=>{dirty=true;document.getElementById('fmDirty').style.display='inline';nums()};T.onscroll=()=>N.scrollTop=T.scrollTop;
T.onkeydown=e=>{if(e.key==='Tab'){e.preventDefault();document.execCommand('insertText',false,'    ')}if((e.ctrlKey||e.metaKey)&&e.key==='s'){e.preventDefault();save()}};
document.getElementById('fmSave').onclick=save;
document.getElementById('fmDl').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([T.value]));a.download=cur.split('/').pop();a.click();URL.revokeObjectURL(a.href)};
document.getElementById('fmDel').onclick=async()=>{if(!confirm(`Delete ${cur}?`))return;if(live){try{await call('DELETE','/api/file?project='+enc(proj)+'&path='+enc(cur))}catch(e){return say(e.message)}}delete fs[cur];dirty=false;const n=Object.keys(fs)[0];cur='';n?load(n):(T.value='',tree(),nums())};
document.getElementById('fmNew').onclick=async()=>{const n=(prompt('New file path (e.g. app/routes.py)')||'').trim().replace(/^\/+/,'');if(!n||/\.\.|[<>:"|?*]/.test(n))return n&&say('Invalid file name.');if(n in fs)return say('File already exists.');if(live){try{await call('PUT','/api/file',{project:proj,path:n,content:''})}catch(e){return say(e.message)}}fs[n]='';if(n.includes('/'))open[n.split('/')[0]]=1;load(n)};
document.getElementById('fmUp').onchange=e=>[...e.target.files].forEach(f=>{if(f.size>512000)return say(`${f.name} is too large for preview (max 500 KB).`);f.text().then(async t=>{if(live){try{await call('PUT','/api/file',{project:proj,path:f.name,content:t})}catch(e){return say(e.message)}}fs[f.name]=t;tree();say(live?`Uploaded ${f.name}`:`Added ${f.name} (preview)`)}).catch(()=>say(`${f.name} is not a text file.`))});
load(cur);
(async()=>{try{const ps=(await call('GET','/api/projects')).projects;live=true;for(const k in fs)delete fs[k];cur='';dirty=false;open={};
document.querySelector('.fm-foot span:last-child').textContent='UTF-8 · Connected: changes are saved to your project on the server';
if(!ps.length){tree();T.value='';nums();return say('No projects found for your account yet.')}
proj=ps[0];document.querySelector('.fm-proj strong').textContent=proj;document.querySelector('.fm-proj small').textContent='/'+proj;
(await call('GET','/api/files?project='+enc(proj))).files.forEach(p=>{fs[p]=null;if(p.includes('/'))open[p.split('/')[0]]=1});
tree();const f0=Object.keys(fs)[0];f0?load(f0):(T.value='',nums())}catch(e){}})()}

const sp=document.getElementById('page-support');if(sp){
const faq=[['How do I deploy a Python bot?','Create a project, choose Python and a version, then set the startup command (for example python main.py). Upload your files in File Manager and start the project.'],['Why is my project stopped?','Projects stop when you stop them manually or when the app exits. Check Console & Logs for the last error, fix it, then start the project again.'],['Which runtime versions are available?','The list is controlled by the platform administrator. See Runtime Manager for what is enabled for your workspace.'],['How much storage and RAM do I get?','Limits depend on your plan. Your current usage is shown in Resource Usage and on the plan card in the sidebar.'],['Can I use my own Docker image?','Yes, choose Custom Docker when creating a project. Availability is controlled by your administrator.']];
sp.innerHTML=`<div class="eyebrow">HELP CENTER</div><h1>Help & Support<span class="accent">.</span></h1><p class="muted">Answers, guides and a direct line to our team.</p>
<div class="help-grid"><a class="panel help-card" href="mailto:support@mannanbot.site"><span class="metric-icon cyan">${I('mail',18)}</span><strong>Email support</strong><small>support@mannanbot.site</small></a><button class="panel help-card" data-go="console"><span class="metric-icon purple">${I('term',18)}</span><strong>Check your logs</strong><small>Most issues show up in the console</small></button><button class="panel help-card" data-go="runtime"><span class="metric-icon blue">${I('book',18)}</span><strong>Runtime guide</strong><small>Versions and compatibility</small></button></div>
<div class="panel faq"><h2>Frequently asked questions</h2>${faq.map(([q,a])=>`<details><summary>${q}${I('chev',16)}</summary><p>${a}</p></details>`).join('')}</div>`;
sp.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>document.querySelector(`.nav-item[data-page="${b.dataset.go}"]`)?.click())}
})();
